This is a theme by kyndder

This version of the theme has been optimised with the following changes:
- The device icons in the /icons folder with .icns extensions are all .png files.